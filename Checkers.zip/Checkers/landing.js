window.onload = function() {
    setTimeout(function() {
        window.location.href = 'main.html'; // Redirect to the main options page
    }, 4000); // 4 seconds delay
};
